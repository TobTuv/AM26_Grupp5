package io.github.jumpyBirb;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.utils.ScreenUtils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import io.github.jumpyBirb.data.Pipe;
import io.github.jumpyBirb.data.Score;
import io.github.jumpyBirb.game.GameState;

public class Main extends ApplicationAdapter {

    // Start of score
    private Boolean start;
    private Boolean alive;
    private double finalScore = 0;

    //all assests goes here before batch;
    Texture backgroundTexture;
    Texture parallaxOneTexture;
    Texture parallaxTwoTexture;
    Texture parallaxThreeTexture;
    Texture bikerTexture;
    Texture skyScraperTexture;
    Texture flyingSkyScraperTextureOne;
    Texture podPlatformTexture;
    Sound jumpSound;
    Music music;
    Music introMusic;
    private BitmapFont font;

    //Parallax settings
    float parallaxOneX = 0;
    float parallaxTwoX = 0;
    float parallaxThreeX = 0;

    float parallaxOneSpeed = 20f;
    float parallaxTwoSpeed = 40f;
    float parallaxThreeSpeed = 80f;

    private SpriteBatch batch;

    float playerY;
    float velocity;
    // add a list of pipes included the top and the bottom.
    List<Pipe> pipes;
    float pipeTimer = 0;

    float podSpeed = 150;

    // pipe variables
    final float GAP = 160;
    final float PIPE_WIDTH = 120;
    final float MIN_PIPE_HEIGHT = 50;
    final float MAX_PIPE_HEIGHT = 250;
    float timeAlive = 0; // use for score
    float timePlaying = 0; // use for harder things.
    float spawnInterval = 2f;


    final float GRAVITY = 800;
    final float JUMP_FORCE = 250;
    float currentJumpForce;

    float CEILING;
    float SCREEN_HEIGHT;
    float SCREEN_WIDTH;

    // Creat a player here
    float playerX = 100;
    float playerWidth = 90;
    float playerHeight = 50;

    // creat a ledged where we start
    float podX = 65;
    float podY = 0;
    float podWidth = 190;
    float podHeight = 215;

    enum PipeSpawnType {
        PAIR,
        TOP,
        BOTTOM
    }

    Score score = new Score();

    @Override
    public void render() {

        update();
        scoreCount();
    }

    void update() {
        float delta = Gdx.graphics.getDeltaTime();

        if (gameState != GameState.RUNNING) {
            handleStartOrRestartInput();
            return;
        }

        if (inputPressed()) {
            player.jump(calculateJumpForce());
        }

        background.update(delta);
        player.update(delta, GRAVITY);
        player.clampToCeiling(CEILING);

        podX -= podSpeed * delta;

        timePlaying += delta;
        score.update(delta, gameState == GameState.RUNNING);

        obstacleManager.update(delta, timePlaying, getPipeSpeed());

        if (player.hitsBottom() || player.hitsTop(CEILING) || obstacleManager.collidesWith(player)) {
            gameOver();
        }
    }

    float getPipeSpeed() {
        return 200 + ((int) (timePlaying / 5)) * 20;
    }

    

    public void scoreCount() {
        float delta = Gdx.graphics.getDeltaTime();
        timeAlive += delta;

        while (timeAlive >= 0.1f) {

            if (!alive) {
                score.resetScore(1, 0);
                break;
            } else if (start) {
                score.resetScore(1, 0);
                break;
            }

            finalScore = score.getScore();
            score.addScore();
            timeAlive -= 0.1f;
        }
    }
}
