package io.github.jumpyBirb.graphics;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;
import io.github.jumpyBirb.data.Pipe;

public class GameRenderer {
    private final SpriteBatch batch;
    private final BitmapFont font;

    public GameRenderer(SpriteBatch batch, BitmapFont font) {
        this.batch = batch;
        this.font = font;
    }

    public void draw(GameWorld world) {
        ScreenUtils.clear(Color.BLACK);

        batch.begin();
        world.getBackground().draw(batch);
        batch.draw(world.getPodTexture(), world.getPodX(), world.getPodY(), world.getPodWidth(), world.getPodHeight());
        batch.draw(world.getPlayerTexture(), world.getPlayer().getX(), world.getPlayer().getY(),
            world.getPlayer().getWidth(), world.getPlayer().getHeight());

        for (Pipe p : world.getObstacleManager().getPipes()) {
            batch.draw(world.getObstacleTexture(), p.x, p.y, p.width, p.height);
        }

        font.draw(batch, "Score: " + (int) world.getScore().getScore(), 270, world.getScreenHeight() - 10);

        if (world.isGameOver()) {
            font.draw(batch, "GAME OVER!\nYour score: " + (int) world.getFinalScore(),
                world.getScreenWidth() / 2 - 30, world.getScreenHeight() / 2);
        }

        batch.end();
    }
}
